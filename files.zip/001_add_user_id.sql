-- ============================================================
-- briancronin-telemetry: Migration for user_id support
-- ============================================================
-- Run this against the briancronin-telemetry Neon Postgres database.
--
-- This migration:
--   1. Adds a nullable user_id column to the events table
--   2. Adds an index on user_id for efficient cross-session queries
--   3. Adds a composite index on (user_id, page) for per-app user queries
--
-- Backward compatible: existing ETF Finder events will have
-- user_id = NULL and continue to work without changes.
-- ============================================================

-- Step 1: Add nullable user_id column
ALTER TABLE events ADD COLUMN IF NOT EXISTS user_id TEXT DEFAULT NULL;

-- Step 2: Index for querying all events by a specific user
CREATE INDEX IF NOT EXISTS idx_events_user_id ON events (user_id) WHERE user_id IS NOT NULL;

-- Step 3: Composite index for per-app user queries
-- e.g., "show me all car-finder events for user X"
CREATE INDEX IF NOT EXISTS idx_events_user_page ON events (user_id, page) WHERE user_id IS NOT NULL;

-- Step 4: Index on page for per-app queries (if not already present)
CREATE INDEX IF NOT EXISTS idx_events_page ON events (page);

-- ============================================================
-- Verification: Run these after the migration to confirm
-- ============================================================
-- SELECT column_name, data_type, is_nullable
-- FROM information_schema.columns
-- WHERE table_name = 'events'
-- ORDER BY ordinal_position;
--
-- Expected output should include:
--   user_id | text | YES
--
-- SELECT indexname FROM pg_indexes WHERE tablename = 'events';
--
-- Expected output should include:
--   idx_events_user_id
--   idx_events_user_page
--   idx_events_page
-- ============================================================

-- ============================================================
-- Useful queries for cross-session user tracking
-- ============================================================
--
-- All sessions for a specific user:
--   SELECT DISTINCT session_id, page, MIN(created_at) as first_event, MAX(created_at) as last_event
--   FROM events
--   WHERE user_id = 'supabase-uuid-here'
--   GROUP BY session_id, page
--   ORDER BY first_event DESC;
--
-- Full journey for a user across all apps:
--   SELECT event_type, event_data, page, session_id, created_at
--   FROM events
--   WHERE user_id = 'supabase-uuid-here'
--   ORDER BY created_at ASC;
--
-- Car finder funnel for a specific user:
--   SELECT event_type, event_data, created_at
--   FROM events
--   WHERE user_id = 'supabase-uuid-here' AND page = 'car-finder'
--   ORDER BY created_at ASC;
--
-- How many visits before a user clicked a deep link:
--   SELECT COUNT(DISTINCT session_id) as total_sessions
--   FROM events
--   WHERE user_id = 'supabase-uuid-here'
--     AND page = 'car-finder'
--     AND created_at <= (
--       SELECT MIN(created_at) FROM events
--       WHERE user_id = 'supabase-uuid-here'
--         AND event_type = 'deep_link_clicked'
--     );
-- ============================================================
