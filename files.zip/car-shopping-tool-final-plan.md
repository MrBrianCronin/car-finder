# Car Shopping Tool — Project Plan (Final)
## briancronin.ai · New Project

**Decisions locked:** March 29, 2026

---

## 1. Vision & Positioning

**What this is:** An AI-powered car matching tool that guides undecided consumers through a structured discovery process — up to 50 questions across lifestyle, budget, driving habits, and preferences — then surfaces vehicle recommendations backed by real government data, personalized Claude-powered narratives, and direct links to find those cars for sale near them.

**What this is NOT:** Another car search engine. The differentiator is the *intake side* — helping people who don't know what they want figure it out, rather than assuming they already know the make/model they're after.

**How it differs from the ETF Finder:** Your ETF tool uses a filter-and-browse paradigm (dropdowns, sliders, results table). The car tool feels like a guided consultation — conversational, progressive, adaptive. Different design language, different interaction model, different energy.

---

## 2. Finalized Decisions

| Decision | Choice | Rationale |
|----------|--------|-----------|
| **Build approach** | Plan all phases, build sequentially, launch when complete | Full data model and architecture designed upfront so nothing gets thrown away |
| **Listing data** | Free deep links to Cars.com / AutoTrader / CarGurus | No redistribution concerns, no recurring cost, pre-populated with recommended make/model/year/zip/radius |
| **AI narratives** | Claude API via serverless proxy with rate limiting + monthly budget cap | 3–5 requests per IP per hour, hard spend cap, graceful degradation to algorithmic output if cap is hit |
| **User accounts** | Google OAuth via Supabase | Postgres + auth on free tier, users can save results and return across devices |
| **Vehicle scope** | 2010+ model years | Covers budget buyers ($5K–$15K) through new car shoppers, transparent about data gaps on older vehicles |
| **Geography** | US only | NHTSA and EPA APIs are US-native, deep links to US marketplace sites, zip code–based |

---

## 3. Design Direction — Breaking from the ETF Finder

| Dimension | ETF Finder (avoid repeating) | Car Shopping Tool (new direction) |
|-----------|------------------------------|-----------------------------------|
| **Interaction model** | Filter panel → results grid | Progressive guided questionnaire → personalized results |
| **Layout** | Dashboard/data-table aesthetic | Editorial, card-based, storytelling flow |
| **Color** | (Existing site palette) | Distinct palette — warm, approachable, automotive-inspired (deep navy, warm amber, matte grays) |
| **Typography** | Data-centric, compact | Larger, editorial — display serif or geometric sans paired with readable body font |
| **Motion** | Minimal/static | Transitions between question stages, card reveals for results, progress indicators |
| **Tone** | Analytical, professional | Friendly advisor — "Let's figure this out together" |
| **Mobile** | Responsive but desktop-first | Mobile-first — car shopping happens on phones |

**Aesthetic concept:** Digital concierge, not spreadsheet. The questionnaire should feel like talking to a knowledgeable friend. Results should feel curated, not dumped.

---

## 4. The Questionnaire — 50 Questions, 8 Categories

Adaptive logic means most users answer 25–35 questions, not all 50. Skip logic is defined per question.

### Stage 1: Budget & Financial Reality (7 questions)

| # | Question | Input Type | Skip Logic |
|---|----------|-----------|------------|
| 1 | What's your total budget? | Slider ($5K–$100K+) | — |
| 2 | Are you open to financing, or is this cash? | Single select | — |
| 3 | If financing, what monthly payment range works? | Slider ($150–$1,500) | Skip if Q2 = "cash" |
| 4 | How important is resale value to you? | 1–5 scale | — |
| 5 | What's your comfort level with maintenance costs? | Low / Medium / High | — |
| 6 | Do you want to minimize fuel/energy costs? | Not important / Somewhat / Very | — |
| 7 | Are you open to new, used, or certified pre-owned? | Multi-select | — |

### Stage 2: Who's Riding? (5 questions)

| # | Question | Input Type | Skip Logic |
|---|----------|-----------|------------|
| 8 | How many people will regularly ride in the car? | Number picker (1–8+) | — |
| 9 | Do you have car seats or plan to? | Yes / No / Maybe | Skip if Q8 ≤ 2 |
| 10 | Do you regularly carry pets? | Yes / No | — |
| 11 | Do you need wheelchair or mobility accessibility? | Yes / No | — |
| 12 | How tall is the tallest regular rider? | Short selector | Skip if Q8 = 1 |

### Stage 3: How & Where You Drive (10 questions)

| # | Question | Input Type | Skip Logic |
|---|----------|-----------|------------|
| 13 | How many miles do you drive per week? | Slider (0–500+) | — |
| 14 | What's your longest regular trip? | Slider (miles) | — |
| 15 | What's your primary driving environment? | Multi-select: City / Suburban / Rural / Highway commute | — |
| 16 | Do you regularly drive on unpaved roads, gravel, or off-road? | Never / Sometimes / Frequently | — |
| 17 | Do you drive in heavy snow or ice? | Never / Sometimes / Frequently | — |
| 18 | How would you describe your driving style? | Relaxed / Balanced / Spirited / Performance-focused | — |
| 19 | How important is a smooth, quiet ride? | 1–5 scale | — |
| 20 | Do you do any towing? | No / Occasionally / Regularly | — |
| 21 | How much cargo space do you need day-to-day? | Minimal / Moderate / A lot / I haul large items | — |
| 22 | Do you need to fit specific items regularly? | Multi-select or free text | — |

### Stage 4: Reliability & Longevity (6 questions)

| # | Question | Input Type | Skip Logic |
|---|----------|-----------|------------|
| 23 | How many total miles do you expect to put on this car? | Slider (30K–300K+) | — |
| 24 | How long do you plan to keep it? | 1–3 yrs / 3–5 / 5–10 / 10+ / Until it dies | — |
| 25 | How important is brand reliability reputation? | 1–5 scale | — |
| 26 | Are you comfortable doing basic maintenance yourself? | Yes / No | — |
| 27 | Do you want a vehicle still under manufacturer warranty? | Must have / Prefer / Don't care | — |
| 28 | How do you feel about recalls? | Not concerned / Somewhat / Very | — |

### Stage 5: Features & Technology (8 questions)

| # | Question | Input Type | Skip Logic |
|---|----------|-----------|------------|
| 29 | How important are advanced safety features? | 1–5 scale | — |
| 30 | Do you want a backup camera? | Need it / Nice to have | — |
| 31 | How important is the infotainment system? | Don't care / Basic is fine / Want the best | — |
| 32 | Do you need Apple CarPlay / Android Auto? | Must have / Nice to have / Don't care | — |
| 33 | How important is a premium sound system? | 1–5 scale | — |
| 34 | Do you want adaptive cruise control or semi-autonomous driving? | Must have / Nice to have / Don't care | — |
| 35 | How important is a sunroof/moonroof? | Must have / Nice to have / Don't care | — |
| 36 | Do you need heated/cooled seats? | Must / Nice / Don't care | — |

### Stage 6: Powertrain & Efficiency (5 questions)

| # | Question | Input Type | Skip Logic |
|---|----------|-----------|------------|
| 37 | Are you open to electric vehicles? | Yes / Maybe / No | — |
| 38 | Are you open to hybrid or plug-in hybrid? | Yes / Maybe / No | — |
| 39 | Do you have access to home charging? | Yes / No / Could install | Skip if Q37 = "No" AND Q38 = "No" |
| 40 | What's the minimum fuel economy you'd accept? | Slider (MPG) or "Don't care" | — |
| 41 | Do you have a preference for engine size/power? | Efficient is fine / Want some power / Need serious power | — |

### Stage 7: Aesthetics & Preferences (5 questions)

| # | Question | Input Type | Skip Logic |
|---|----------|-----------|------------|
| 42 | What body styles appeal to you? | Multi-select with images | — |
| 43 | Do you prefer a specific size? | Compact / Midsize / Full-size / Don't care | — |
| 44 | Are there brands you love or refuse to consider? | Include/exclude brand selector | — |
| 45 | How important is exterior appearance to you? | 1–5 scale | — |
| 46 | Do you prefer a higher driving position or lower/sportier? | High / Low / No preference | — |

### Stage 8: Deal-Breakers & Final Preferences (4 questions)

| # | Question | Input Type | Skip Logic |
|---|----------|-----------|------------|
| 47 | What's the maximum mileage you'd accept on a used car? | Slider (10K–200K) | Skip if Q7 = "New only" |
| 48 | How far are you willing to travel to buy? | Slider (miles) or "Ship to me" | — |
| 49 | What's your zip code? | Text input | — |
| 50 | Anything else we should know? | Open text | — |

---

## 5. Data Architecture

### Vehicle Database — Free Public Sources

| Source | Data Provided | API | Cost | Legal Status |
|--------|--------------|-----|------|-------------|
| **NHTSA vPIC** | VIN decode, make/model/year specs, body style, engine, drivetrain, fuel type, GVWR | REST/JSON | Free | Public domain |
| **NHTSA Safety Ratings** | NCAP crash test scores (overall, frontal, side, rollover) | REST/JSON | Free | Public domain |
| **NHTSA Recalls** | Recall campaigns by make/model/year, components, remedies | REST/JSON | Free | Public domain |
| **NHTSA Complaints** | Consumer complaints with crash/fire/injury flags | REST/JSON | Free | Public domain |
| **EPA FuelEconomy.gov** | MPG (city/highway/combined), annual fuel cost, CO₂ emissions, EV range, size class | REST/JSON & CSV | Free | Public domain |

### Self-Curated Datasets

| Dataset | Source Method | Purpose |
|---------|-------------|---------|
| **Reliability scores** | Normalize NHTSA complaint counts per make/model/year relative to estimated sales volume | Proxy reliability ranking |
| **Maintenance cost estimates** | Curate from RepairPal, YourMechanic annual studies, AAA cost-of-ownership reports | Match to budget comfort (Q5) |
| **Expected lifespan** | Curate from iSeeCars longevity studies, fleet data | Match to total miles expectation (Q23) |
| **Feature availability by MY** | NHTSA vPIC features + manual curation for infotainment/ADAS by model year | Match to Q29–36 |

### Listing Deep Links (No API Required)

| Marketplace | Deep Link Pattern | Parameters Supported |
|-------------|------------------|---------------------|
| **Cars.com** | `cars.com/shopping/results/?...` | Make, model, year range, price range, zip, radius, drivetrain, fuel type |
| **AutoTrader.com** | `autotrader.com/cars-for-sale/...` | Make, model, year range, price range, zip, radius |
| **CarGurus** | `cargurus.com/Cars/inventorylisting/...` | Make, model, year range, price range, zip, distance |

Deep links will be pre-populated from the recommendation + user's questionnaire answers (zip, budget, condition preference).

---

## 6. Matching Algorithm

### Input → Filter → Score Pipeline

```
Questionnaire Answers
       ↓
  Hard Filters (eliminate non-matches)
    • Price range
    • Body style preferences
    • Seating capacity minimum
    • Condition (new/used/CPO)
    • Powertrain (EV/hybrid/ICE)
    • Brand include/exclude list
    • Model year ≥ 2010
       ↓
  Soft Scoring (rank remaining candidates)
    Each dimension scored 0–100, weighted by user's stated priorities:
    
    • Price fit — how well does typical market price fit their budget?
    • Reliability — inverse complaint rate per NHTSA data
    • Safety — NHTSA star rating (overall + component scores)
    • Fuel economy — MPG vs. user's driving pattern (weekly miles × city/hwy split)
    • Size fit — seating + cargo vs. stated needs
    • Feature match — % of desired features present
    • Terrain capability — drivetrain + ground clearance vs. conditions
    • Maintenance cost fit — estimated annual cost vs. comfort level
    • Longevity fit — expected lifespan vs. ownership plan
    • Ride quality — noise/comfort ratings vs. importance
    • Resale value — depreciation curve vs. importance
       ↓
  Composite Score = Σ (weight_i × score_i)
       ↓
  Top 5–10 vehicles ranked by composite score
       ↓
  Claude API generates personalized narrative per vehicle
       ↓
  Results displayed with specs, scores, narrative, and deep links
```

### Weight Derivation from Questionnaire

User's answers directly set the weights. Examples:
- Q25 "How important is reliability?" = 5/5 → reliability weight = 1.0
- Q6 "Minimize fuel costs?" = "Not important" → fuel economy weight = 0.2
- Q19 "Smooth quiet ride?" = 1/5 → ride quality weight = 0.2
- Q4 "Resale value?" = 4/5 → resale weight = 0.8

Weights normalize so they sum to 1.0 across all dimensions.

---

## 7. Technical Architecture

### Frontend

| Component | Technology | Notes |
|-----------|-----------|-------|
| Questionnaire UI | React (JSX) | Progressive card-based flow with stage transitions |
| State management | React useReducer | Full questionnaire state, skip logic evaluation |
| Results display | React cards + data viz | Composite score bar, comparison mode, narrative blocks |
| Styling | Tailwind CSS | Mobile-first, distinct automotive palette |
| Animations | CSS transitions + Motion | Stage transitions, card reveals, progress bar |
| Hosting | briancronin.ai (static) | Same infrastructure as existing site |

### Backend

| Component | Technology | Notes |
|-----------|-----------|-------|
| Auth | Supabase Auth (Google OAuth) | Free tier, handles sessions, JWT tokens |
| Database | Supabase Postgres | Users, saved questionnaire answers, saved results |
| Claude API proxy | Cloudflare Worker or Vercel Edge Function | Rate limiting (3–5 req/IP/hr), budget cap enforcement |
| Vehicle database | Static JSON served from CDN | Pre-computed from NHTSA + EPA + curated data, ~2–5MB |
| Matching engine | Client-side JavaScript | Scoring runs in browser, no server round-trip for filtering |
| Telemetry | Shared Vercel Postgres (briancronin-telemetry) via Neon | Same DB and API as ETF Finder — all apps write to one `events` table |

### Telemetry Architecture

The car shopping tool shares the same telemetry infrastructure as the ETF Finder and all future briancronin.ai apps.

**Shared infrastructure (already deployed):**
- **Database:** `briancronin-telemetry` on Vercel Postgres (Neon)
- **API route:** Shared `api/telemetry.js` Vercel serverless function
- **Tables:** `events` (all app events) + `write_counter` (monthly cap)

**What changes for the car shopping tool:**

1. **Database migration** — Add nullable `user_id TEXT` column to the `events` table + indexes for cross-session queries. Backward compatible: ETF Finder events continue with `user_id = NULL`.

2. **Server-side API** — Updated allowlist adds car-finder event types. Updated INSERT statement writes `user_id` when present. All existing security (rate limiting, payload validation, monthly cap, CORS, origin check) remains unchanged.

3. **Client-side module** — Same pattern as ETF Finder but with two new functions: `setUserId(id)` called after Google OAuth login, and `clearUserId()` called on logout. When a user is logged in, every event includes their Supabase UUID, enabling multi-visit journey tracking.

**Car-finder event types:**

| Event | Tracked Data | Purpose |
|-------|-------------|---------|
| `page_view` | URL, referrer | Entry point tracking |
| `session_heartbeat` | — | Time-on-page measurement |
| `question_answered` | Question #, stage, value | Funnel analysis, drop-off detection |
| `question_skipped` | Question #, reason | Adaptive logic coverage |
| `stage_completed` | Stage name (1–8) | Stage-level funnel |
| `questionnaire_completed` | Total questions answered, time elapsed | Completion rate |
| `questionnaire_restarted` | — | Re-engagement signal |
| `recommendation_viewed` | Make, model, year, rank, score | Which results get attention |
| `recommendation_expanded` | Make, model, year | Deep engagement signal |
| `narrative_loaded` | Vehicle count | Claude API success tracking |
| `narrative_fallback` | Reason (budget_cap, rate_limit, error) | Degradation monitoring |
| `comparison_opened` | Vehicle count | Feature adoption |
| `comparison_vehicle_added` | Make, model, year | Comparison behavior |
| `comparison_vehicle_removed` | Make, model, year | Comparison behavior |
| `deep_link_clicked` | Marketplace, make, model, year | Conversion proxy |
| `results_saved` | Session ID | Persistence adoption |
| `results_loaded` | Session ID | Return visit tracking |
| `login_completed` | — (user_id attached automatically) | Auth tracking |
| `login_failed` | Error type | Auth debugging |
| `logout` | — | Session boundary |

**Cross-session query examples:**

```sql
-- All sessions for a user across all apps
SELECT DISTINCT session_id, page, MIN(created_at) as first_event
FROM events WHERE user_id = 'uuid' GROUP BY session_id, page;

-- Car finder funnel for a specific user
SELECT event_type, event_data, created_at FROM events
WHERE user_id = 'uuid' AND page = 'car-finder' ORDER BY created_at;

-- How many visits before first deep link click
SELECT COUNT(DISTINCT session_id) FROM events
WHERE user_id = 'uuid' AND page = 'car-finder'
  AND created_at <= (SELECT MIN(created_at) FROM events
    WHERE user_id = 'uuid' AND event_type = 'deep_link_clicked');
```

**Files produced:**
- `api/telemetry.js` — Updated shared API route (replaces existing)
- `src/telemetry.js` — Car-finder client-side module (new)
- `migrations/001_add_user_id.sql` — Database migration (run once)

### Database Schema (Supabase)

```sql
-- Users (managed by Supabase Auth)
-- profiles table extends auth.users
CREATE TABLE profiles (
  id UUID REFERENCES auth.users PRIMARY KEY,
  display_name TEXT,
  zip_code TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Saved questionnaire sessions
CREATE TABLE sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES profiles(id),
  answers JSONB NOT NULL,          -- Full questionnaire answers
  computed_weights JSONB,          -- Derived scoring weights
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Saved recommendation results
CREATE TABLE results (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id UUID REFERENCES sessions(id),
  user_id UUID REFERENCES profiles(id),
  recommendations JSONB NOT NULL,  -- Top vehicles with scores
  narratives JSONB,                -- Claude-generated narratives
  created_at TIMESTAMPTZ DEFAULT NOW()
);
```

### Claude API Integration

```
User completes questionnaire
       ↓
Client sends answers + top 5 vehicle matches to serverless proxy
       ↓
Proxy checks:
  • IP rate limit (3–5 req/hr) → 429 if exceeded
  • Monthly budget counter → fallback to algorithmic if cap hit
       ↓
Proxy calls Anthropic API:
  Model: claude-sonnet-4-20250514
  System prompt: "You are a knowledgeable car advisor. Given the user's 
    questionnaire answers and the top vehicle matches with their scores, 
    write a personalized 2–3 sentence explanation for each vehicle 
    explaining why it's a good fit, referencing specific answers the 
    user gave. Be warm, specific, and honest about trade-offs."
  User message: {answers} + {vehicles with scores and data}
       ↓
Proxy returns narratives to client
       ↓
Client renders results with narratives
  (or algorithmic fallback if proxy returned budget-exceeded)
```

### Data Pipeline (Build Phase)

```
Step 1: Pull all makes/models/trims for 2010–2026 from NHTSA vPIC
Step 2: Enrich with EPA FuelEconomy.gov data (MPG, fuel costs, emissions, size class)
Step 3: Pull safety ratings from NHTSA Safety Ratings API
Step 4: Aggregate complaint counts from NHTSA Complaints API
Step 5: Aggregate recall counts from NHTSA Recalls API
Step 6: Merge with curated maintenance cost and lifespan estimates
Step 7: Decode feature availability per make/model/year from NHTSA vPIC
Step 8: Normalize all numeric scores to 0–100 scales
Step 9: Export as structured JSON (~2–5MB for 2010+ vehicles)
Step 10: Host JSON on CDN, refresh quarterly
```

---

## 8. Build Phases (Sequential, Launch When Complete)

### Phase 1: Foundation (Weeks 1–3)
**Goal:** Questionnaire + vehicle database + algorithmic matching + telemetry

- [ ] Run database migration (`001_add_user_id.sql`) on briancronin-telemetry
- [ ] Deploy updated shared `api/telemetry.js` with car-finder event types + user_id support
- [ ] Integrate client-side `src/telemetry.js` — call `initTelemetry('car-finder')` on app load
- [ ] Design and build questionnaire UI (React, card-based, mobile-first)
- [ ] Implement all 50 questions with adaptive skip logic
- [ ] Instrument questionnaire with telemetry (question_answered, stage_completed, etc.)
- [ ] Run data pipeline to build vehicle database JSON from NHTSA + EPA
- [ ] Build matching/scoring algorithm (client-side)
- [ ] Display results as ranked cards with specs, scores, strengths/weaknesses
- [ ] Build deep link generator for Cars.com / AutoTrader / CarGurus
- [ ] Instrument results with telemetry (recommendation_viewed, deep_link_clicked, etc.)

### Phase 2: Data Enrichment (Weeks 4–6)
**Goal:** Richer data, better scoring

- [ ] Curate and integrate maintenance cost estimates per make/model
- [ ] Build reliability scoring (complaint rate normalization per estimated sales)
- [ ] Build total cost of ownership calculator (purchase + fuel + maintenance + insurance estimate over ownership period)
- [ ] Add vehicle comparison feature (side-by-side, up to 3 vehicles)
- [ ] Add data gap transparency ("safety feature data not available for this model year")
- [ ] Build and test data refresh pipeline (quarterly cadence)

### Phase 3: Accounts & Persistence (Weeks 7–8)
**Goal:** Users can save and return, telemetry tracks cross-session journeys

- [ ] Set up Supabase project (Postgres + Auth)
- [ ] Implement Google OAuth login flow
- [ ] Wire `setUserId()` / `clearUserId()` to auth state changes
- [ ] Instrument login/logout telemetry events
- [ ] Build save/load for questionnaire sessions
- [ ] Build save/load for recommendation results
- [ ] Instrument results_saved / results_loaded telemetry
- [ ] Add "My Saved Searches" dashboard
- [ ] Add ability to re-run with modified answers

### Phase 4: AI Narratives (Weeks 9–11)
**Goal:** Claude-powered personalized explanations

- [ ] Deploy serverless proxy (Cloudflare Worker or Vercel Edge Function)
- [ ] Implement IP-based rate limiting (3–5 req/IP/hr)
- [ ] Implement monthly budget cap with counter
- [ ] Design and test Claude API prompt for vehicle narratives
- [ ] Build graceful degradation (algorithmic fallback when cap hit)
- [ ] Integrate narratives into results UI
- [ ] Add conversational follow-up ("I liked this one but want something sportier")

### Phase 5: Polish & Launch (Weeks 12–13)
**Goal:** Production-ready

- [ ] Design integration with briancronin.ai (navigation, page layout, consistent with site but distinct from ETF Finder)
- [ ] Performance optimization (lazy load vehicle DB, code splitting)
- [ ] Mobile testing and refinement
- [ ] Accessibility pass (WCAG 2.1 AA)
- [ ] Error handling and edge cases
- [ ] Verify telemetry data flowing correctly across all phases
- [ ] Launch

---

## 9. Cost Summary

| Item | Cost | Frequency |
|------|------|-----------|
| NHTSA APIs | Free | — |
| EPA FuelEconomy.gov | Free | — |
| Supabase (free tier) | $0 | Monthly (up to 50K MAU, 500MB DB) |
| Cloudflare Worker (free tier) | $0 | Monthly (up to 100K req/day) |
| Anthropic API (Claude Sonnet) | ~$3/1K input tokens, ~$15/1K output tokens | Per request, capped monthly |
| **Estimated monthly API spend** | **$5–$20** (with budget cap) | Monthly |
| Domain / hosting | Already covered by briancronin.ai | — |

---

## 10. Why This Project Works on briancronin.ai

- **Data engineering showcase:** Building a vehicle database from 5 government APIs, normalizing and scoring — this is pipeline work
- **Agentic AI in action:** Claude-powered narratives demonstrate the agentic AI capabilities you lead professionally
- **Full-stack product thinking:** Questionnaire design → matching algorithms → data architecture → API integration → auth → UX
- **Consumer-facing data product:** Shows range beyond enterprise internal tools
- **Differentiated from ETF Finder:** Different design language, different interaction model, different domain — demonstrates versatility
- **Real utility:** People will actually use this, which is the best portfolio piece of all
