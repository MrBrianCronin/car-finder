# Car Finder — Chat Handoff Document
## Context Transfer from Planning Chat → Build Chat

**Date:** March 29, 2026
**Project:** Car Shopping Tool for briancronin.ai
**Status:** Phase 1 code complete, not yet deployed

---

## 1. What This Project Is

An AI-powered car matching tool for briancronin.ai. It guides consumers who don't know what car they want through an adaptive 50-question questionnaire (most users answer ~30 due to skip logic), then scores vehicles from a database against their answers across 11 dimensions, and presents ranked recommendations with specs, ratings, match reasons, trade-offs, and deep links to find those cars on Cars.com, AutoTrader, and CarGurus.

It is intentionally designed to look and feel completely different from the ETF Finder — editorial/concierge aesthetic vs. data-table/dashboard. Different fonts (DM Serif Display + Outfit), different palette (navy/amber/stone vs. ETF Finder's scheme), card-based progressive flow vs. filter-and-browse.

---

## 2. All Decisions Made

| Decision | Choice |
|----------|--------|
| Build approach | Plan all phases upfront, build sequentially, launch when complete |
| Listing data | Free deep links to Cars.com / AutoTrader / CarGurus (no paid API) |
| AI narratives | Claude API via serverless proxy with IP rate limiting (3–5 req/hr) + monthly budget cap, graceful degradation to algorithmic |
| User accounts | Google OAuth via Supabase (Postgres + auth, free tier) |
| Vehicle scope | 2010+ model years |
| Geography | US only |
| Telemetry | Shared Vercel Postgres (briancronin-telemetry) — same DB and API as ETF Finder |
| Telemetry user tracking | Optional `user_id` column on events table, populated after OAuth login, enabling cross-session journey tracking |
| Telemetry user_id approach | Top-level field on each event (not buried in event_data JSON) |

---

## 3. Phase 1 — What Was Built (COMPLETE)

### Project Structure

```
car-finder/
├── index.html                     # Entry point, loads DM Serif Display + Outfit fonts
├── package.json                   # React 19 + Vite
├── vite.config.js
├── .gitignore
├── README.md
├── api/
│   └── telemetry.js               # Shared Vercel serverless function (updated with car-finder events + user_id)
└── src/
    ├── main.jsx                   # React root
    ├── App.jsx                    # Main app — useReducer state, 3-phase flow (welcome → questionnaire → results)
    ├── styles.css                 # Full stylesheet — navy/amber/stone palette, mobile-first
    ├── telemetry.js               # Client-side telemetry with setUserId/clearUserId
    ├── components/
    │   ├── WelcomeScreen.jsx      # Landing page with CTA
    │   ├── ProgressBar.jsx        # Question progress indicator
    │   ├── StageIndicator.jsx     # 8-stage dot navigation
    │   ├── QuestionCard.jsx       # All 7 input types (slider, single_select, multi_select, scale, number, text, brand_selector)
    │   └── ResultsView.jsx        # Ranked vehicle cards with score bars, specs, deep links
    ├── data/
    │   ├── questions.js           # All 50 questions with skip logic, organized into 8 stages
    │   └── vehicles.js            # ~35 representative vehicles (placeholder — replaced by NHTSA/EPA pipeline in Phase 2)
    └── engine/
        └── matcher.js             # Scoring engine: deriveWeights(), applyFilters(), scoreVehicle(), findMatches()
```

### Separate Deliverables (not inside the project folder)

```
api-telemetry.js                   # Updated shared API route (replaces ETF Finder's version)
src-telemetry.js                   # Car-finder client telemetry module (same as what's in car-finder/src/)
001_add_user_id.sql                # Database migration for briancronin-telemetry
car-shopping-tool-final-plan.md    # Full project plan with all phases
```

### How to Run Locally

```bash
cd car-finder
npm install
npm run dev
# Opens at http://localhost:5173
```

---

## 4. Telemetry Architecture

The car finder shares the same telemetry infrastructure as the ETF Finder:

- **Database:** `briancronin-telemetry` on Vercel Postgres (Neon)
- **Shared API:** `api/telemetry.js` deployed as a Vercel serverless function
- **Tables:** `events` (all app events, differentiated by `page` column) + `write_counter` (monthly cap)

### What Changed for Car Finder

1. **Database migration needed:** Run `001_add_user_id.sql` — adds nullable `user_id TEXT` column + indexes. Backward compatible with ETF Finder.

2. **Server-side API updated:** Allowlist now includes car-finder event types. INSERT now writes `user_id`. All existing security unchanged.

3. **Client-side module:** New `setUserId(id)` and `clearUserId()` functions for cross-session tracking after OAuth login.

### Car Finder Event Types Added to Allowlist

```
question_answered, question_skipped, stage_completed,
questionnaire_completed, questionnaire_restarted,
recommendation_viewed, recommendation_expanded,
narrative_loaded, narrative_fallback,
comparison_opened, comparison_vehicle_added, comparison_vehicle_removed,
deep_link_clicked, results_saved, results_loaded,
login_completed, login_failed, logout
```

---

## 5. Matching Engine Summary

**Pipeline:** User answers → derive weights → hard filter vehicles → soft score across 11 dimensions → composite rank → generate deep links → generate match reasons/trade-offs

**11 Scoring Dimensions:**
1. Price fit (how well price matches budget)
2. Reliability (complaint-based score)
3. Safety (NHTSA star rating)
4. Fuel economy (MPG normalized by fuel type)
5. Size fit (seating + cargo vs. needs)
6. Feature match (% of must-have features present)
7. Terrain capability (drivetrain vs. driving conditions)
8. Maintenance cost (annual cost vs. comfort level)
9. Longevity (lifespan vs. ownership plan)
10. Ride quality (placeholder — enriched in Phase 2)
11. Resale value (curated score)

**Weights are derived dynamically** from the user's answers. If they say reliability is "extremely important" (5/5), it gets maximum weight. If they say "don't care" about fuel costs, fuel economy weight drops to 0.2.

---

## 6. Design System

| Element | Choice |
|---------|--------|
| Display font | DM Serif Display (serif) — headlines, question text, vehicle names |
| Body font | Outfit (geometric sans) — UI text, options, specs |
| Primary color | Navy `#1a2332` — headers, buttons, selected states |
| Accent color | Amber `#D4A574` — badges, progress, highlights |
| Background | Stone `#F5F0EB` — warm off-white |
| Cards | White `#FFFFFF` with subtle shadow |
| Stage colors | Amber, Sky, Sage, Coral, Plum, Teal, Gold, Slate — one per questionnaire stage |
| Interaction | Slide animations between questions, expand/collapse for vehicle details |
| Mobile | Mobile-first breakpoints, stacked layouts below 640px |

---

## 7. Remaining Phases (Not Yet Built)

### Phase 2: Data Enrichment (Weeks 4–6)
- Replace `vehicles.js` placeholder with real NHTSA/EPA data pipeline output
- Curate maintenance cost estimates per make/model
- Build reliability scoring (complaint rate normalization per estimated sales volume)
- Total cost of ownership calculator
- Vehicle comparison feature (side-by-side, up to 3)
- Data gap transparency for older model years
- Quarterly data refresh pipeline

### Phase 3: Accounts & Persistence (Weeks 7–8)
- Supabase project setup (Postgres + Google OAuth)
- Wire `setUserId()`/`clearUserId()` to auth state
- Save/load questionnaire sessions and results
- "My Saved Searches" dashboard
- Re-run with modified answers

### Phase 4: AI Narratives (Weeks 9–11)
- Serverless proxy for Claude API (Cloudflare Worker or Vercel Edge Function)
- IP rate limiting (3–5 req/hr) + monthly budget cap
- Claude API prompt for personalized vehicle narratives
- Graceful degradation to algorithmic fallback
- Conversational follow-up ("I liked this one but want something sportier")

### Phase 5: Polish & Launch (Weeks 12–13)
- Integration with briancronin.ai navigation
- Performance optimization (lazy load vehicle DB, code splitting)
- Mobile testing, accessibility pass (WCAG 2.1 AA)
- Error handling, edge cases
- Telemetry verification
- Launch

---

## 8. Deployment Notes

**Stack:** React 19 + Vite, deployed on Vercel (same as ETF Finder)

**To deploy:**
1. Push `car-finder/` to a new GitHub repo (e.g., `MrBrianCronin/car-finder`)
2. Connect to Vercel
3. Add environment variable: `DATABASE_URL` → your existing `briancronin-telemetry` Neon connection string
4. Run `001_add_user_id.sql` against the `briancronin-telemetry` database (one-time migration)
5. The `api/telemetry.js` in this project replaces the shared one — deploy it to the shared location or ensure both ETF Finder and Car Finder point to the same API route

**Important:** The updated `api/telemetry.js` is backward compatible. ETF Finder events continue working unchanged — they just have `user_id = NULL`.

---

## 9. Data Sources for Phase 2 Pipeline

All free, all public domain, all US government:

| API | Base URL | What It Provides |
|-----|----------|-----------------|
| NHTSA vPIC | `https://vpic.nhtsa.dot.gov/api/` | Vehicle specs (make/model/year/trim, engine, drivetrain, fuel type, body style, GVWR) |
| NHTSA Safety Ratings | `https://api.nhtsa.gov/SafetyRatings/` | NCAP crash test scores (overall, frontal, side, rollover) |
| NHTSA Complaints | `https://api.nhtsa.gov/complaints/` | Consumer complaints by make/model/year with crash/fire/injury flags |
| NHTSA Recalls | `https://api.nhtsa.gov/recalls/` | Recall campaigns by make/model/year |
| EPA FuelEconomy.gov | `https://www.fueleconomy.gov/feg/ws/` | MPG (city/hwy/combined), annual fuel cost, CO₂ emissions, EV range, size class |

**Pipeline steps:** Pull all makes/models/trims for 2010–2026 → enrich with EPA data → pull safety ratings → aggregate complaints → aggregate recalls → merge curated maintenance/lifespan estimates → normalize scores → export as JSON.

---

## 10. Supabase Schema (Phase 3)

```sql
CREATE TABLE profiles (
  id UUID REFERENCES auth.users PRIMARY KEY,
  display_name TEXT,
  zip_code TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES profiles(id),
  answers JSONB NOT NULL,
  computed_weights JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE results (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id UUID REFERENCES sessions(id),
  user_id UUID REFERENCES profiles(id),
  recommendations JSONB NOT NULL,
  narratives JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW()
);
```

---

## 11. Claude API Integration (Phase 4)

**Model:** claude-sonnet-4-20250514
**Estimated cost:** $5–20/month with budget cap

**System prompt:**
```
You are a knowledgeable car advisor. Given the user's questionnaire answers and the top vehicle matches with their scores, write a personalized 2–3 sentence explanation for each vehicle explaining why it's a good fit, referencing specific answers the user gave. Be warm, specific, and honest about trade-offs.
```

**Protection layers:**
1. Questionnaire must be fully completed before API fires (natural bot gate)
2. IP-based rate limiting: 3–5 requests per IP per hour
3. Hard monthly spend cap on Anthropic API key
4. Graceful degradation: if cap is hit, serve algorithmic results (still functional, just without narrative)

---

## 12. Key Files to Reference in Other Chat

When continuing work, these are the most important files to have context on:

| File | Why It Matters |
|------|---------------|
| `src/App.jsx` | Main state machine — understand the useReducer, the 3 phases, and how data flows |
| `src/data/questions.js` | All 50 questions with skip logic — this is the product definition |
| `src/engine/matcher.js` | The scoring algorithm — weights, filters, scoring dimensions, deep link generation |
| `src/data/vehicles.js` | Placeholder vehicle DB — needs to be replaced with real data in Phase 2 |
| `src/telemetry.js` | Client telemetry — already instrumented throughout the app |
| `api/telemetry.js` | Server telemetry — shared with ETF Finder, updated with car-finder events |
| `src/styles.css` | Full design system — navy/amber/stone palette, all component styles |
| `001_add_user_id.sql` | Database migration — run once before deploying |

---

## 13. What to Tell the Other Chat

Paste this summary at the start of the new chat:

> I'm building a car shopping tool for my briancronin.ai site. I've completed Phase 1 planning and code in another chat. I have a `car-finder.tar.gz` archive with the full React + Vite project, plus separate telemetry files and a database migration. The project has 50 questions across 8 stages with adaptive skip logic, a client-side scoring engine that matches across 11 dimensions, and results with deep links to Cars.com/AutoTrader/CarGurus. Design uses DM Serif Display + Outfit fonts with a navy/amber/stone palette — intentionally different from my ETF Finder. Telemetry shares the same Vercel Postgres DB as my other apps (briancronin-telemetry). I need to [deploy it / start Phase 2 / integrate it with my main site / etc.]. I'm uploading the handoff document and project files now.
